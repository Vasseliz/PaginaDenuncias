import React, { useContext } from 'react';
import { Shield } from 'lucide-react';
import { DenunciaProvider, DenunciaContext } from './context/DenunciaContext';

import ProgressBar from './components/ProgressBar';
import BotaoEscolha from './components/BotaoEscolha';
import FormularioDinamico from './components/FormularioDinamico';

import FormularioCompleto from './Paginas/FormularioCompleto';
import Termos from './Paginas/Termos';
import Finalizar from './Paginas/Finalizar';

const MainContent = () => {
  const { currentStep } = useContext(DenunciaContext);

  const renderStep = () => {
    switch (currentStep) {
      case 'tipo': return <BotaoEscolha />;
      case 'modalidade': return <FormularioDinamico />;
      case 'formulario': return <FormularioCompleto />;
      case 'termos': return <Termos />;
      case 'finalizar': return <Finalizar />;
      default: return <BotaoEscolha />;
    }
  };

  return (
    <div className="px-4 py-6 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      <div className="max-w-4xl mx-auto">
        <ProgressBar />
        <div className="mt-4 sm:mt-6 lg:mt-8">
          {renderStep()}
        </div>
      </div>
    </div>
  );
};

const App = () => (
  <DenunciaProvider>
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Shield className="w-6 h-6 sm:w-8 sm:h-8 text-blue-600" />
              <h1 className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-800">Denúncias</h1>
            </div>
            <div className="text-xs sm:text-sm text-gray-500">Seguro & Confidencial</div>
          </div>
        </div>
      </header>
      <MainContent />
    </div>
  </DenunciaProvider>
);

export default App;